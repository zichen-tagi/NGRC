﻿san = load('F:\rc\SAN_LASER.txt');
narma = load('F:\rc\NARMAu10_Labels.txt');
lx = load('F:\rc\Lorenz63_d15Labels_X.txt');
ly = load('F:\rc\Lorenz63_d15Labels_Y.txt');
lz = load('F:\rc\Lorenz63_d15Labels_Z.txt');
window_size = 300;
out = 'C:\Users\我想飞\Desktop\NGRC论文\Source_Data\Fig3\Fig3a_raw_task_sequences.csv';
T = table((1:window_size)', san(1:window_size), narma(1:window_size), lx(1:window_size), ly(1:window_size), lz(1:window_size), ...
    'VariableNames', {'time_step','SantaFe_amplitude','NARMA10_target','Lorenz63_x','Lorenz63_y','Lorenz63_z'});
writetable(T, out);
