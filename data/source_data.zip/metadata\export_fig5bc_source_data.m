﻿close all; clear; clc;
cd('F:\rc\conc');
load('conc.mat');
resol = time_axis(2) - time_axis(1);
num_frames_total = size(all_data_ch2, 2);

dn = 9.9e-9;
J0_ch2 = 1229 + 20;
J0_ch1 = 955 + 2;
num_groups = 2000;
frames_per_group = 3 * 14;
step = 2000;
num_pulses_ch1 = 55;
num_pulses_ch2 = 55;
bg_offset_pts = round(1e-9 / resol);
all_avg_peaks_ch1 = cell(num_groups, 1);
all_avg_peaks_ch2 = cell(num_groups, 1);

for g = 1:num_groups
    indices = g + (0:frames_per_group-1) * step;
    indices = indices(indices <= num_frames_total);
    if isempty(indices), continue; end

    temp_pks_1 = NaN(length(indices), num_pulses_ch1);
    for i = 1:length(indices)
        current_frame = all_data_ch1(:, indices(i));
        valid_frame = true;
        frame_pks = zeros(1, num_pulses_ch1);
        frame_locs = zeros(1, num_pulses_ch1);
        for p = 1:num_pulses_ch1
            J_center = J0_ch1 + (p-1)*round(dn/resol);
            J_left = J_center - 29; J_right = J_center + 29;
            if J_left > bg_offset_pts && J_right < length(current_frame)
                [raw_max, max_idx] = max(current_frame(J_left:J_right));
                frame_pks(p) = raw_max;
                frame_locs(p) = J_left + max_idx - 1;
                if p > 1 && (frame_locs(p) - frame_locs(p-1)) >= 90
                    valid_frame = false;
                    break;
                end
            end
        end
        if valid_frame
            temp_pks_1(i, :) = frame_pks;
        end
    end

    temp_pks_2 = NaN(length(indices), num_pulses_ch2);
    for i = 1:length(indices)
        current_frame = all_data_ch2(:, indices(i));
        valid_frame = true;
        frame_pks = zeros(1, num_pulses_ch2);
        frame_locs = zeros(1, num_pulses_ch2);
        for p = 1:num_pulses_ch2
            J_center = J0_ch2 + (p-1)*round(dn/resol);
            J_left = J_center - 29; J_right = J_center + 29;
            if J_left > bg_offset_pts && J_right < length(current_frame)
                [raw_max, max_idx] = max(current_frame(J_left:J_right));
                frame_pks(p) = raw_max;
                frame_locs(p) = J_left + max_idx - 1;
                if p > 1 && (frame_locs(p) - frame_locs(p-1)) >= 90
                    valid_frame = false;
                    break;
                end
            end
        end
        if valid_frame
            temp_pks_2(i, :) = frame_pks;
        end
    end

    all_avg_peaks_ch1{g} = mean(temp_pks_1, 1, 'omitnan');
    all_avg_peaks_ch2{g} = mean(temp_pks_2, 1, 'omitnan');
end

X_ch1 = cell2mat(all_avg_peaks_ch1);
X_ch2 = cell2mat(all_avg_peaks_ch2);
X_ch1 = fillmissing(X_ch1, 'previous'); X_ch1 = fillmissing(X_ch1, 'constant', 0);
X_ch2 = fillmissing(X_ch2, 'previous'); X_ch2 = fillmissing(X_ch2, 'constant', 0);
X_physical = [X_ch1, X_ch2];

Y_labels = load('Concrete_Labels_2000.txt');
Y_labels = Y_labels(:);
min_len = min(size(X_physical, 1), length(Y_labels));
X_data = X_physical(1:min_len, :);
Y_data = Y_labels(1:min_len);
train_ratio = 0.8;
train_len = floor(min_len * train_ratio);
test_len = min_len - train_len;
X_train = X_data(1:train_len, :);
X_test = X_data(train_len+1:end, :);
Y_train = Y_data(1:train_len);
Y_test = Y_data(train_len+1:end);

X_train_bias = [ones(train_len, 1), X_train];
X_test_bias = [ones(test_len, 1), X_test];
alpha = 1e-6;
I = eye(size(X_train_bias, 2)); I(1,1) = 0;
W_out = (X_train_bias' * X_train_bias + alpha * I) \ (X_train_bias' * Y_train);
Y_train_score = X_train_bias * W_out;
Y_test_score = X_test_bias * W_out;
threshold = 0.5;
Y_train_pred = double(Y_train_score >= threshold);
Y_test_pred = double(Y_test_score >= threshold);
train_acc = sum(Y_train_pred == Y_train) / length(Y_train);
test_acc = sum(Y_test_pred == Y_test) / length(Y_test);

C = confusionmat(Y_test, Y_test_pred);
C_norm = C ./ sum(C, 2);
TP = sum((Y_test_pred == 1) & (Y_test == 1));
TN = sum((Y_test_pred == 0) & (Y_test == 0));
FP = sum((Y_test_pred == 1) & (Y_test == 0));
FN = sum((Y_test_pred == 0) & (Y_test == 1));
Precision = TP / (TP + FP + 1e-10);
Recall = TP / (TP + FN + 1e-10);
F1_Score = 2 * (Precision * Recall) / (Precision + Recall + 1e-10);

outdir = 'C:\Users\我想飞\Desktop\NGRC论文\Source_Data\Fig5';
Tscore = table((1:test_len)', (train_len+1:min_len)', Y_test, Y_test_score, Y_test_pred, ...
    repmat(threshold, test_len, 1), ...
    'VariableNames', {'test_sample_index','global_sample_index','true_label','regression_score','predicted_label','threshold'});
writetable(Tscore, fullfile(outdir, 'Fig5b_concrete_regression_scores.csv'));

class_names = {'Normal'; 'Crack'};
Tconf = table;
Tconf.true_class = [class_names; class_names];
Tconf.predicted_class = [repmat(class_names(1), 2, 1); repmat(class_names(2), 2, 1)];
Tconf.count = [C(1,1); C(2,1); C(1,2); C(2,2)];
Tconf.row_normalized_value = [C_norm(1,1); C_norm(2,1); C_norm(1,2); C_norm(2,2)];
writetable(Tconf, fullfile(outdir, 'Fig5c_concrete_confusion_matrix.csv'));

Tmetrics = table(train_len, test_len, train_acc, test_acc, threshold, TP, TN, FP, FN, Precision, Recall, F1_Score);
writetable(Tmetrics, fullfile(outdir, 'Fig5_classification_metrics.csv'));
save(fullfile(outdir, 'Fig5_classification_source_data.mat'), 'Y_test', 'Y_test_score', 'Y_test_pred', 'threshold', 'C', 'C_norm', 'train_acc', 'test_acc', 'TP', 'TN', 'FP', 'FN', 'Precision', 'Recall', 'F1_Score');

fprintf('Exported Fig. 5b-c source data. Test accuracy = %.4f\n', test_acc);
disp(C);
disp(C_norm);
