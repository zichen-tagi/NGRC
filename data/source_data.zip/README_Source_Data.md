# Source Data for NGRC Manuscript

This folder contains submit-ready source data files for manuscript figures that
are generated from numerical data.

## Folder Structure

```text
Source_Data/
  Fig3/
    Fig3a_raw_task_sequences.csv
    Fig3b_SantaFe_single_lattice_prediction.csv
    Fig3c_NARMA10_single_lattice_prediction.csv
    Fig3d_Lorenz63_single_lattice_prediction.csv
  Fig4/
    Fig4bcd_benchmark_and_feature_diagnostics.csv
  Fig5/
    Fig5_concrete_labels.csv
    Fig5_input_FFT_features_and_labels.csv
    Fig5b_concrete_regression_scores.csv
    Fig5c_concrete_confusion_matrix.csv
    Fig5_classification_metrics.csv
    Fig5_classification_source_data.mat
  Supplementary_Figures/
    Supplementary_Fig2_peak_extraction_source.csv
    Supplementary_Fig3_multilattice_feature_matrices_source.csv
    Supplementary_Fig4_ridge_only_baseline_source.csv
    Supplementary_Fig5_cumulative_spectral_energy_source.csv
  metadata/
    Source_Data_mapping.csv
```

## Fig. 3 Source Data

`Fig3a_raw_task_sequences.csv` contains the plotted raw task sequences used for
the workflow panel: Santa Fe chaotic laser, NARMA10, and Lorenz63 x/y/z traces.

`Fig3b_SantaFe_single_lattice_prediction.csv`,
`Fig3c_NARMA10_single_lattice_prediction.csv`, and
`Fig3d_Lorenz63_single_lattice_prediction.csv` contain test-set sample index,
task name, condition, ground truth, prediction, and the corresponding NMSE value.
Where available, the ridge-only prediction is also included as an additional
column.

## Fig. 4 Source Data

`Fig4bcd_benchmark_and_feature_diagnostics.csv` contains the values plotted in
Fig. 4b-d, including NMSE benchmark comparison, effective rank, and mean absolute
pairwise feature correlation.

## Fig. 5 Source Data

`Fig5_concrete_labels.csv` contains the class label for each concrete image
sample.

`Fig5_input_FFT_features_and_labels.csv` contains the 49 Fourier-domain input
features extracted from each concrete image, together with the sample index and
class label. These data support the image-preprocessing stage shown in Fig. 5.

`Fig5b_concrete_regression_scores.csv` contains the test-set class labels,
continuous regression scores, predicted labels, and decision threshold used to
plot the model-score distribution in Fig. 5b.

`Fig5c_concrete_confusion_matrix.csv` contains the count and row-normalized
confusion matrix values used in Fig. 5c. `Fig5_classification_metrics.csv`
contains the corresponding train/test split sizes, accuracy, precision, recall,
and F1 score. `Fig5_classification_source_data.mat` stores the MATLAB variables
`Y_test`, `Y_test_score`, `Y_test_pred`, `threshold`, `C`, and `C_norm`.

## Supplementary Figure Source Data

`Supplementary_Fig2_peak_extraction_source.csv` contains the temporal-site
centres, extracted peak indices, peak times, peak values, and search-window
widths used to plot the oscilloscope peak-extraction example.

`Supplementary_Fig3_multilattice_feature_matrices_source.csv` contains the
z-score-normalized matrix values used for the multi-lattice feature-matrix
visualization. The table is stored in long format with matrix name, sample
index, feature channel, and value.

`Supplementary_Fig4_ridge_only_baseline_source.csv` contains the NMSE values
used in the ridge-only baseline comparison. The corresponding prediction traces
are stored in the Fig. 3 source-data CSV files, which include the
`ridge_only_prediction` column.

`Supplementary_Fig5_cumulative_spectral_energy_source.csv` contains the
cumulative singular-value spectral-energy curves used to plot the feature-rank
diagnostic.

## Raw Experimental Data

Raw oscilloscope waveform files are not included in this source-data package
because of their large file size. The CSV files here provide the plotted source
data and compact processed data needed to inspect the reported figure panels.
