﻿function export_source_data_package()
root = 'C:\Users\我想飞\Desktop\NGRC论文\Source_Data';

%% Fig. 3 source data: target and prediction traces
export_prediction_trace(...
    'F:\rc\0.018plot_fastframe2UV_1000samp1_6G\plot_data.mat', ...
    fullfile(root, 'Fig3', 'Fig3b_SantaFe_single_lattice_prediction.csv'), ...
    'Santa Fe', 'single-lattice');
export_prediction_trace(...
    'F:\rc\0.096plot_nrU10d30\narma_data.mat', ...
    fullfile(root, 'Fig3', 'Fig3c_NARMA10_single_lattice_prediction.csv'), ...
    'NARMA10', 'single-lattice');
export_prediction_trace(...
    'F:\rc\0036最好结果_1lorenz63d15globalcross\lorenz_data_d30.mat', ...
    fullfile(root, 'Fig3', 'Fig3d_Lorenz63_single_lattice_prediction.csv'), ...
    'Lorenz63', 'single-lattice');
add_lorenz_d30_ridge_only(...
    fullfile(root, 'Fig3', 'Fig3d_Lorenz63_single_lattice_prediction.csv'), ...
    'F:\rc\0036最好结果_1lorenz63d15globalcross');

%% Fig. 4 source data: benchmark comparison and feature-space diagnostics
fig4 = table;
fig4 = [fig4; make_rows('4b', 'Santa Fe', {'Previous Best','Single-Lattice','Multi-Lattice (Fused)'}, [0.0290, 0.0325, 0.0252], 'NMSE')];
fig4 = [fig4; make_rows('4b', 'NARMA10', {'Previous Best','Single-Lattice','Multi-Lattice (Fused)'}, [0.1070, 0.1099, 0.0983], 'NMSE')];
fig4 = [fig4; make_rows('4b', 'Lorenz63', {'Previous Best','Single-Lattice','Multi-Lattice (Fused)'}, [0.0143, 0.0379, 0.0184], 'NMSE')];
fig4 = [fig4; make_rows('4c', 'Santa Fe', {'Single-Lattice','Multi-Lattice (Fused)'}, [33.97, 109.85], 'effective_rank')];
fig4 = [fig4; make_rows('4c', 'NARMA10', {'Single-Lattice','Multi-Lattice (Fused)'}, [49.61, 107.99], 'effective_rank')];
fig4 = [fig4; make_rows('4c', 'Lorenz63', {'Single-Lattice','Multi-Lattice (Fused)'}, [46.04, 103.16], 'effective_rank')];
fig4 = [fig4; make_rows('4d', 'Santa Fe', {'Single-Lattice','Multi-Lattice (Fused)'}, [0.3367, 0.2288], 'mean_abs_pairwise_feature_correlation')];
fig4 = [fig4; make_rows('4d', 'NARMA10', {'Single-Lattice','Multi-Lattice (Fused)'}, [0.1058, 0.1108], 'mean_abs_pairwise_feature_correlation')];
fig4 = [fig4; make_rows('4d', 'Lorenz63', {'Single-Lattice','Multi-Lattice (Fused)'}, [0.2158, 0.2629], 'mean_abs_pairwise_feature_correlation')];
writetable(fig4, fullfile(root, 'Fig4', 'Fig4bcd_benchmark_and_feature_diagnostics.csv'));

%% Fig. 5 available source data: labels and FFT input features
raw = load('F:\rc\conc\raw_fft_features.mat');
X_raw = raw.X_raw;
Y_raw = raw.Y_raw(:);
feature_names = strings(1, size(X_raw, 2));
for k = 1:size(X_raw, 2)
    feature_names(k) = "fft_feature_" + k;
end
Traw = array2table(X_raw, 'VariableNames', cellstr(feature_names));
Traw.sample_index = (1:size(X_raw, 1))';
Traw.class_label = Y_raw;
Traw = movevars(Traw, {'sample_index','class_label'}, 'Before', 1);
writetable(Traw, fullfile(root, 'Fig5', 'Fig5_input_FFT_features_and_labels.csv'));

labels = table((1:numel(Y_raw))', Y_raw, 'VariableNames', {'sample_index','class_label'});
writetable(labels, fullfile(root, 'Fig5', 'Fig5_concrete_labels.csv'));
end

function export_prediction_trace(matfile_path, out_csv, task, condition)
S = load(matfile_path);
T = table;
T.sample_index = (1:numel(S.Y_test))';
T.task = repmat(string(task), numel(S.Y_test), 1);
T.condition = repmat(string(condition), numel(S.Y_test), 1);
T.ground_truth = S.Y_test(:);
T.prediction = S.Y_test_pred(:);
if isfield(S, 'Y_ridge_test_pred')
    T.ridge_only_prediction = S.Y_ridge_test_pred(:);
end
if isfield(S, 'NMSE_Correct')
    T.NMSE = repmat(S.NMSE_Correct, numel(S.Y_test), 1);
end
writetable(T, out_csv);
end

function add_lorenz_d30_ridge_only(out_csv, data_dir)
T = readtable(out_csv);
series_x = load(fullfile(data_dir, 'Lorenz63_d30Labels_X.txt'));
series_y = load(fullfile(data_dir, 'Lorenz63_d30Labels_Y.txt'));
series_z = load(fullfile(data_dir, 'Lorenz63_d30Labels_Z.txt'));
series_x = series_x(:);
series_y = series_y(:);
series_z = series_z(:);

series_x = (series_x - min(series_x)) / (max(series_x) - min(series_x));
series_y = (series_y - min(series_y)) / (max(series_y) - min(series_y));
series_z = (series_z - min(series_z)) / (max(series_z) - min(series_z));

ridge_memory = 15;
train_len = 1600;
test_len = height(T);
ridge_total = train_len + test_len - ridge_memory;
X_ridge_only = zeros(ridge_total, 2 * ridge_memory);
for k = 1:ridge_total
    X_ridge_only(k, :) = [series_x(k : k + ridge_memory - 1).', ...
        series_y(k : k + ridge_memory - 1).'];
end
Y_ridge_labels = series_z(ridge_memory + 1 : ridge_memory + ridge_total);

ridge_train_len = train_len - ridge_memory;
X_ridge_train = X_ridge_only(1:ridge_train_len, :);
X_ridge_test = X_ridge_only(ridge_train_len + 1 : ridge_train_len + test_len, :);
Y_ridge_train = Y_ridge_labels(1:ridge_train_len);
Y_ridge_test = Y_ridge_labels(ridge_train_len + 1 : ridge_train_len + test_len);

target_mismatch = max(abs(Y_ridge_test - T.ground_truth));
if target_mismatch > 1e-10
    error('Lorenz63 d30 ridge-only target does not match Fig. 3d source data.');
end

alpha_ridge_only = 1e-9;
X_ridge_train_bias = [ones(ridge_train_len, 1), X_ridge_train];
X_ridge_test_bias = [ones(test_len, 1), X_ridge_test];
I_ridge = eye(size(X_ridge_train_bias, 2));
I_ridge(1,1) = 0;
W_ridge_only = (X_ridge_train_bias' * X_ridge_train_bias + alpha_ridge_only * I_ridge) \ ...
    (X_ridge_train_bias' * Y_ridge_train);
T.ridge_only_prediction = X_ridge_test_bias * W_ridge_only;
writetable(T, out_csv);
end

function T = make_rows(panel, task, series, values, metric)
T = table;
T.panel = repmat(string(panel), numel(values), 1);
T.task = repmat(string(task), numel(values), 1);
T.series = string(series(:));
T.metric = repmat(string(metric), numel(values), 1);
T.value = values(:);
end
