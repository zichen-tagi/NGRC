project_root = fileparts(mfilename('fullpath'));
supp_dir = fullfile(project_root, 'Source_Data', 'Supplementary_Figures');
if ~exist(supp_dir, 'dir')
    mkdir(supp_dir);
end

revised_dir = fullfile(project_root, 'Supplementary_Figures_Revised');
copyfile(fullfile(revised_dir, 'Supplementary_Fig2_peak_extraction_source.csv'), ...
    fullfile(supp_dir, 'Supplementary_Fig2_peak_extraction_source.csv'));
copyfile(fullfile(revised_dir, 'Supplementary_Fig4_ridge_only_baseline_source.csv'), ...
    fullfile(supp_dir, 'Supplementary_Fig4_ridge_only_baseline_source.csv'));
copyfile(fullfile(revised_dir, 'Supplementary_Fig5_cumulative_spectral_energy_source.csv'), ...
    fullfile(supp_dir, 'Supplementary_Fig5_cumulative_spectral_energy_source.csv'));

cache_file = fullfile('F:\rc', '0036最好结果_1lorenz63d15globalcross', ...
    'lorenz_feature_matrices_cache.mat');
S = load(cache_file);
X1 = normalize_block(S.X_d15(1:120, 1:55));
X2 = normalize_block(S.X_d30p(1:120, 1:55));
X3 = normalize_block(S.X_d30g(1:120, 1:55));
Xf = [X1 X2 X3];

matrix_names = {'Lattice config 1', 'Lattice config 2', ...
    'Lattice config 3', 'Fused feature matrix'};
matrix_data = {X1, X2, X3, Xf};
T = table();
for i = 1:numel(matrix_data)
    X = matrix_data{i};
    [rr, cc] = ndgrid(1:size(X, 1), 1:size(X, 2));
    Ti = table;
    Ti.panel = repmat("Supplementary Fig. 3", numel(X), 1);
    Ti.matrix = repmat(string(matrix_names{i}), numel(X), 1);
    Ti.sample_index = rr(:);
    Ti.feature_channel = cc(:);
    Ti.z_score_value = X(:);
    T = [T; Ti]; %#ok<AGROW>
end
writetable(T, fullfile(supp_dir, ...
    'Supplementary_Fig3_multilattice_feature_matrices_source.csv'));

fprintf('Exported supplementary source data to %s\n', supp_dir);

function Xn = normalize_block(X)
    Xn = zscore(X, 0, 1);
    Xn(:, all(~isfinite(Xn), 1)) = 0;
    Xn(~isfinite(Xn)) = 0;
end
