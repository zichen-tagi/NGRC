project_root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
supp_dir = fullfile(project_root, 'Source_Data', 'Supplementary_Figures');
if ~exist(supp_dir, 'dir')
    mkdir(supp_dir);
end

revised_dir = fullfile(project_root, 'Supplementary_Figures_Revised');
copyfile(fullfile(revised_dir, 'Supplementary_Fig2_peak_extraction_source.csv'), ...
    fullfile(supp_dir, 'Supplementary_Fig2_peak_extraction_source.csv'));
copyfile(fullfile(revised_dir, 'Supplementary_Fig3_ridge_only_baseline_source.csv'), ...
    fullfile(supp_dir, 'Supplementary_Fig3_ridge_only_baseline_source.csv'));
copyfile(fullfile(revised_dir, 'Supplementary_Fig4_cumulative_spectral_energy_source.csv'), ...
    fullfile(supp_dir, 'Supplementary_Fig4_cumulative_spectral_energy_source.csv'));

fprintf('Exported supplementary source data to %s\n', supp_dir);
