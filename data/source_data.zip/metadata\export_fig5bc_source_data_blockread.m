﻿close all; clear; clc;
cd('F:\rc\conc');
X_physical = extract_classification_features_blockread('conc.mat', 955 + 2, 1229 + 20, 42);

Y_labels = load('Concrete_Labels_2000.txt');
Y_labels = Y_labels(:);
min_len = min(size(X_physical, 1), length(Y_labels));
X_data = X_physical(1:min_len, :);
Y_data = Y_labels(1:min_len);
train_ratio = 0.8;
train_len = floor(min_len * train_ratio);
test_len = min_len - train_len;
X_train = X_data(1:train_len, :);
X_test = X_data(train_len+1:end, :);
Y_train = Y_data(1:train_len);
Y_test = Y_data(train_len+1:end);

X_train_bias = [ones(train_len, 1), X_train];
X_test_bias = [ones(test_len, 1), X_test];
alpha = 1e-6;
I = eye(size(X_train_bias, 2)); I(1,1) = 0;
W_out = (X_train_bias' * X_train_bias + alpha * I) \ (X_train_bias' * Y_train);
Y_train_score = X_train_bias * W_out;
Y_test_score = X_test_bias * W_out;
threshold = 0.5;
Y_train_pred = double(Y_train_score >= threshold);
Y_test_pred = double(Y_test_score >= threshold);
train_acc = sum(Y_train_pred == Y_train) / length(Y_train);
test_acc = sum(Y_test_pred == Y_test) / length(Y_test);

C = confusionmat(Y_test, Y_test_pred);
C_norm = C ./ sum(C, 2);
TP = sum((Y_test_pred == 1) & (Y_test == 1));
TN = sum((Y_test_pred == 0) & (Y_test == 0));
FP = sum((Y_test_pred == 1) & (Y_test == 0));
FN = sum((Y_test_pred == 0) & (Y_test == 1));
Precision = TP / (TP + FP + 1e-10);
Recall = TP / (TP + FN + 1e-10);
F1_Score = 2 * (Precision * Recall) / (Precision + Recall + 1e-10);

outdir = 'C:\Users\我想飞\Desktop\NGRC论文\Source_Data\Fig5';
Tscore = table((1:test_len)', (train_len+1:min_len)', Y_test, Y_test_score, Y_test_pred, ...
    repmat(threshold, test_len, 1), ...
    'VariableNames', {'test_sample_index','global_sample_index','true_label','regression_score','predicted_label','threshold'});
writetable(Tscore, fullfile(outdir, 'Fig5b_concrete_regression_scores.csv'));

true_classes = ["Normal"; "Crack"];
pred_classes = ["Normal"; "Crack"];
rows = strings(4,1); cols = strings(4,1); counts = zeros(4,1); norms = zeros(4,1);
idx = 0;
for i = 1:2
    for j = 1:2
        idx = idx + 1;
        rows(idx) = true_classes(i);
        cols(idx) = pred_classes(j);
        counts(idx) = C(i,j);
        norms(idx) = C_norm(i,j);
    end
end
Tconf = table(rows, cols, counts, norms, 'VariableNames', {'true_class','predicted_class','count','row_normalized_value'});
writetable(Tconf, fullfile(outdir, 'Fig5c_concrete_confusion_matrix.csv'));

Tmetrics = table(train_len, test_len, train_acc, test_acc, threshold, TP, TN, FP, FN, Precision, Recall, F1_Score);
writetable(Tmetrics, fullfile(outdir, 'Fig5_classification_metrics.csv'));
save(fullfile(outdir, 'Fig5_classification_source_data.mat'), 'Y_test', 'Y_test_score', 'Y_test_pred', 'threshold', 'C', 'C_norm', 'train_acc', 'test_acc', 'TP', 'TN', 'FP', 'FN', 'Precision', 'Recall', 'F1_Score');

fprintf('Exported Fig. 5b-c source data. Test accuracy = %.4f\n', test_acc);
disp(C);
disp(C_norm);

function X_physical = extract_classification_features_blockread(mat_filename, J0_ch1, J0_ch2, frames_per_group)
    data = matfile(mat_filename);
    time_axis = data.time_axis;
    resol = time_axis(2) - time_axis(1);
    data_size = size(data, 'all_data_ch2');
    num_rows = data_size(1);
    num_frames_total = data_size(2);

    dn = 9.9e-9;
    num_groups = 2000;
    step = 2000;
    num_pulses = 55;
    bg_offset_pts = round(1e-9 / resol);
    pulse_step_pts = round(dn / resol);

    X_ch1 = NaN(num_groups, num_pulses);
    X_ch2 = NaN(num_groups, num_pulses);

    for g = 1:num_groups
        if mod(g, 100) == 0
            fprintf('Extracting concrete features: group %d/%d\n', g, num_groups);
        end
        indices = g + (0:frames_per_group-1) * step;
        indices = indices(indices <= num_frames_total);
        if isempty(indices), continue; end

        X_ch1(g, :) = process_channel(data, 'all_data_ch1', indices, J0_ch1, num_pulses, pulse_step_pts, bg_offset_pts, num_rows);
        X_ch2(g, :) = process_channel(data, 'all_data_ch2', indices, J0_ch2, num_pulses, pulse_step_pts, bg_offset_pts, num_rows);
    end

    X_ch1 = fillmissing(X_ch1, 'previous'); X_ch1 = fillmissing(X_ch1, 'constant', 0);
    X_ch2 = fillmissing(X_ch2, 'previous'); X_ch2 = fillmissing(X_ch2, 'constant', 0);
    X_physical = [X_ch1, X_ch2];
end

function avg_pks = process_channel(data, varname, indices, J0, num_pulses, pulse_step_pts, bg_offset_pts, num_rows)
    left_edges = J0 + (0:num_pulses-1) * pulse_step_pts - 29;
    right_edges = J0 + (0:num_pulses-1) * pulse_step_pts + 29;
    valid_pulse_window = left_edges > bg_offset_pts & right_edges < num_rows;
    row_min = max(1, min(left_edges(valid_pulse_window)));
    row_max = min(num_rows, max(right_edges(valid_pulse_window)));

    if isempty(row_min) || isempty(row_max) || row_min > row_max
        avg_pks = zeros(1, num_pulses);
        return;
    end

    block = data.(varname)(row_min:row_max, indices);
    pks = NaN(numel(indices), num_pulses);
    for i = 1:numel(indices)
        current_frame = block(:, i);
        valid_frame = true;
        frame_pks = zeros(1, num_pulses);
        frame_locs = zeros(1, num_pulses);
        for p = 1:num_pulses
            if valid_pulse_window(p)
                local_left = left_edges(p) - row_min + 1;
                local_right = right_edges(p) - row_min + 1;
                [raw_max, max_idx] = max(current_frame(local_left:local_right));
                frame_pks(p) = raw_max;
                frame_locs(p) = left_edges(p) + max_idx - 1;
                if p > 1 && frame_locs(p-1) ~= 0 && (frame_locs(p) - frame_locs(p-1)) >= 90
                    valid_frame = false;
                    break;
                end
            end
        end
        if valid_frame
            pks(i, :) = frame_pks;
        end
    end
    avg_pks = mean(pks, 1, 'omitnan');
end
